classdef extendedModel < ModelClass
	methods
		function [obj] = extendedModel()
